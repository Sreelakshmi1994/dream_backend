var db=require('../dbconnection');
var fs = require('fs');
const storedProcedure = require('../helpers/stored-procedure');
var FCM = require('fcm-node');
    var serverKey = 'AAAAP1i3MJ0:APA91bHASQ7S7EkOPtLtVG7y3VxVsXWAi2LXsSFXwZWeTXIT5iG9usMyXXkckY_frLJ2JwOy4-aYQs7_BKaMjopHfdqQp94jvICyn1j-9kd5hP_SwM-3svy7Fq6xMf6Ml_O9YhIf7L1B';
    var fcm = new FCM(serverKey);
var Job_Posting=
{ 
// Save_Job_Posting: function (Job_Posting_Data, callback)
// {
//     console.log(Job_Posting_Data,'1')
//     var Job_Posting_Value_ = 0;
//     let Job_Posting_ = Job_Posting_Data.Job_Posting;
//     if (Job_Posting_ != undefined && Job_Posting_ != '' && Job_Posting_ != null)
//     Job_Posting_Value_ = 1
//     var FollowUp_Value_ = 0;
//     let FollowUp_ = Job_Posting_Data.Followup;
//     if (FollowUp_ != undefined && FollowUp_ != '' && FollowUp_ != null)
//     FollowUp_Value_ = 1;
//     return db.query("CALL Save_Job_Posting(" + "@Job_Posting_:=?," + "@FollowUp_ :=?," + "@Job_Posting_Value_ :=?," +"@FollowUp_Value_ :=? )"
//     , [Job_Posting_, FollowUp_, Job_Posting_Value_, FollowUp_Value_ ],callback);
// },
// Save_Job_Posting:function(Job_Posting_,callback)
//  { 
//      console.log(Job_Posting_)
//     return db.query("CALL Save_Job_Posting("+"@Job_Posting_Id_ :=?,"+"@Job_Code_ :=?,"+"@Job_Title_ :=?,"+
//     "@Descritpion_ :=?,"+"@Skills_ :=?,"+"@No_Of_Vaccancy_ :=?,"+"@Experience_ :=?,"+"@Experience_Name_ :=?,"+
//     "@Job_Location_ :=?,"+ "@Qualification_ :=?,"+"@Qualification_Name_ :=?,"+"@Functional_Area_ :=?,"+
//     "@Functional_Area_Name_ :=?,"+ "@Specialization_ :=?,"+"@Specialization_Name_ :=?,"+"@Salary_ :=?,"+
//     "@Last_Date_ :=?,"+ "@Company_Id_ :=?,"+ "@Company_Name_ :=?,"+"@Address_ :=?,"+"@Contact_Name_ :=?,"+"@Contact_No_ :=?,"+
//     "@Email_ :=?,"+ "@Address1_ :=?,"+"@Address2_ :=?,"+"@Address3_ :=?,"+"@Address4_ :=?,"+"@Pincode_ :=?,"+
//     "@Status_ :=?,"+"@Logo_ :=?,"+"@User_Id_ :=?,"+"@Course_Id_ :=?,"+"@Course_Name_ :=?,"+"@Gender_Id_ :=?,"+"@Gender_Name_ :=?"+")"
//  ,[Job_Posting_.Job_Posting_Id,Job_Posting_.Job_Code,Job_Posting_.Job_Title,Job_Posting_.Descritpion,
//     Job_Posting_.Skills,Job_Posting_.No_Of_Vaccancy,Job_Posting_.Experience,Job_Posting_.Experience_Name,
//     Job_Posting_.Job_Location,Job_Posting_.Qualification,Job_Posting_.Qualification_Name,Job_Posting_.Functional_Area,
//     Job_Posting_.Functional_Area_Name,Job_Posting_.Specialization,Job_Posting_.Specialization_Name,Job_Posting_.Salary,
//     Job_Posting_.Last_Date,Job_Posting_.Company_Id,Job_Posting_.Company_Name,Job_Posting_.Address,Job_Posting_.Contact_Name,
//     Job_Posting_.Contact_No,Job_Posting_.Email,Job_Posting_.Address1,Job_Posting_.Address2,Job_Posting_.Address3,
//     Job_Posting_.Address4,Job_Posting_.Pincode,Job_Posting_.Status,Job_Posting_.Logo,Job_Posting_.User_Id,Job_Posting_.Course_Id,Job_Posting_.Course_Name,
//     Job_Posting_.Gender_Id,Job_Posting_.Gender_Name
// ],callback);
//  } ,
Delete_Job_Posting:function(Job_Posting_Id_,callback)
{ 
    return db.query("CALL Delete_Job_Posting(@Job_Posting_Id_ :=?)",[Job_Posting_Id_],callback);
} ,
Get_Job_Posting:function(Job_Posting_Id_,callback)
{ 
    return db.query("CALL Get_Job_Posting(@Job_Posting_Id_ :=?)",[Job_Posting_Id_],callback);
} ,
Search_Job_Posting: async function ( Job_Code_ ,Job_id_ ,Job_Location_ ,Company_id_,Pointer_Start_,Pointer_Stop_,Page_Length_) {
    var Job_Posting = [];
     try {
        if (Job_Code_ === undefined || Job_Code_ === "undefined")
            Job_Code_ = '';

            if (Pointer_Start_===undefined || Pointer_Start_==="undefined" )
            Pointer_Start_=0;

            if (Pointer_Stop_===undefined || Pointer_Stop_==="undefined" )
            Pointer_Stop_=0; 
        // if (Job_Title_ === undefined || Job_Title_ === "undefined")
        //     Job_Title_ = '';
         if (Job_Location_ === undefined || Job_Location_ === "undefined")
             Job_Location_ = '';
         Job_Posting = await (new storedProcedure('Search_Job_Posting', [Job_Code_ ,Job_id_ ,Job_Location_ ,Company_id_,Pointer_Start_,Pointer_Stop_,Page_Length_])).result();
     }
     catch (e) 
     {
     }
     return { returnvalue: {Job_Posting}
     };
   },



   Search_Jobposting_Summary: function ( Is_Date_,Fromdate_,Todate_,Job_id_,Company_id_,callback
) {
    // if (Job_Title_ === undefined || Job_Title_ === "undefined")
    // Job_Title_ = "";

    // if (Company_Name_ === undefined || Company_Name_ === "undefined")
    // Company_Name_ = "";


    return db.query(
        "CALL Search_Jobposting_Summary(@Is_Date_ :=?,@Fromdate_ :=?,@Todate_ :=?,@Job_id_ :=?,@Company_id_ :=?)",
        [Is_Date_, Fromdate_,Todate_, Job_id_,Company_id_,],
        callback
    );
},

Search_Appliedcount_Details: function (Job_Posting_Id_,Job_Title_, callback) {
    return db.query(
        "CALL Search_Appliedcount_Details(@Job_Posting_Id_ :=?,@Job_Title_ :=?)",
        [Job_Posting_Id_,Job_Title_],
        callback
    );
},


Search_Rejectedcount_Details: function (Job_Posting_Id_,Job_Title_, callback) {
    return db.query(
        "CALL Search_Rejectedcount_Details(@Job_Posting_Id_ :=?,@Job_Title_ :=?)",
        [Job_Posting_Id_,Job_Title_],
        callback
    );
},


Get_Resumefilefor_Report: function (Student_Id_, callback) {
    return db.query(
        "CALL Get_Resumefilefor_Report(@Student_Id_ :=?)",
        [Student_Id_],
        callback
    );
},

Search_Student_Job_Report: function ( Is_Date_,Fromdate_,Todate_,Student_Status_,Student_Name_,Offeredcount_,Blacklist_Status_,Activate_Status_,Fees_Status_,callback
    ) {
        
        return db.query(
            "CALL Search_Student_Job_Report(@Is_Date_ :=?,@Fromdate_ :=?,@Todate_ :=?,@Student_Status_ :=?,@Student_Name_ :=?,@Offeredcount_ :=?,@Blacklist_Status_ :=?,@Activate_Status_ :=?,@Fees_Status_ :=?)",
            [Is_Date_, Fromdate_,Todate_, Student_Status_,Student_Name_,Offeredcount_, Blacklist_Status_,Activate_Status_,Fees_Status_],
            callback
        );
    },


    // Save_Schedule_Interview: function ( Interview_Schedule_Date_ ,temp_Applied_jobs_ ,Interview_Schedule_Description_ ,Login_User_,temp_Student_d,callback
    //     ) {
    //         // console.log(Interview_Schedule_Date_ ,temp_Applied_jobs_ ,Interview_Schedule_Description_ ,Login_User_,temp_Student_d)
    //         return db.query(
    //             "CALL Save_Schedule_Interview(@Interview_Schedule_Date_ :=?,@temp_Applied_jobs_ :=?,@Interview_Schedule_Description_ :=?,@Login_User_ :=?,@temp_Student_d :=?)",
    //             [Interview_Schedule_Date_ ,temp_Applied_jobs_ ,Interview_Schedule_Description_ ,Login_User_,temp_Student_d],
    //             callback
    //         );
    //     },
    //     Save_Mark_Placement: function ( Placement_Date_ ,temp_Applied_jobs_ ,Placement_Description_ ,Login_User_,temp_Student_d,callback
    //         ) {
    //             // console.log(Placement_Date_ ,temp_Applied_jobs_ ,Placement_Description_ ,Login_User_,temp_Student_d)
    //             return db.query(
    //                 "CALL Save_Mark_Placement(@Placement_Date_ :=?,@temp_Applied_jobs_ :=?,@Placement_Description_ :=?,@Login_User_ :=?,@temp_Student_d :=?)",
    //                 [Placement_Date_ ,temp_Applied_jobs_ ,Placement_Description_ ,Login_User_,temp_Student_d],
    //                 callback
    //             );
    //         },
    

            Search_Jobposting_Detailed_Report: function ( Is_Date_,Fromdate_,Todate_,Company_,Job_,Student_Status_,Blacklist_Status_,Activate_Status_,Fees_Status_,callback
                ) {
                    
                    return db.query(
                        "CALL Search_Jobposting_Detailed_Report(@Is_Date_ :=?,@Fromdate_ :=?,@Todate_ :=?,@Company_ :=?,@Job_ :=?,@Student_Status_ :=?,@Blacklist_Status_ :=?,@Activate_Status_ :=?,@Fees_Status_ :=?)",
                        [Is_Date_,Fromdate_,Todate_,Company_,Job_,Student_Status_,Blacklist_Status_,Activate_Status_,Fees_Status_],
                        callback
                    );
                },




                Search_Job_Rejections: function ( Is_Date_,Fromdate_,Todate_,callback
                    ) {
                        
                        return db.query(
                            "CALL Search_Job_Rejections(@Is_Date_ :=?,@Fromdate_ :=?,@Todate_ :=?)",
                            [Is_Date_,Fromdate_,Todate_],
                            callback
                        );
                    },
    
                    Applied_Reject_Detaild_Report: function (Student_Id_,callback
                        ) {
                            
                            return db.query(
                                "CALL Applied_Reject_Detaild_Report(@Student_Id_ :=?)",
                                [Student_Id_],
                                callback
                            );
                        },
        
    
                    
// Save_Job_Posting: async function (Data) 
// {
//    var Email_=Data.Email;
//    console.log(Email_)
//         return new Promise(async (rs,rej)=>{
//        const pool = db.promise();
//         let result1;
//          var connection = await pool.getConnection();
//         await connection.beginTransaction();         
//          try
//           {
//            const result1 = await(new storedProcedure('Save_Job_Posting',[Email_], connection)).result(); 

//            await connection.commit();
//            connection.release(); 
//                          let transporter = nodemailer.createTransport({
//                             host: 'smtp.gmail.com',
//                              port: 587,
//                              secure: false,
//                              requireTLS: true,
//                              auth: {
//                               user:'enquiry@netcomitservices.com', 
//                                 pass: 'Enquiry@123456',
//                             }
//                           });                      
//                           const msg = {
//                            from: 'enquiry@netcomitservices.com', 
//                              to: Email_, 
//                              subject: 'Forgot Password ', 
//                              html:"Dear "+result1[0].Client_Accounts_Name+""
//                              +"<br/>We have received your Forgot password request. Following is your password to login on NetCom Services.<br/>"
//                              +"<br></br>"
//                              +"<br/> Password : "+result1[0].Password+" <br/>"
//                              +"<br></br>"
//                              +"<br/> Once logged in successfully, you will need to change the above password. <br/>"
//                              +"<br></br>"
//                              +"<br/> Best regards, <br/>"
//                              +"<br/> NetCom<br/>"
//                              +"<br></br>"
//                              +"<br/> Replies to this message are undeliverable and will not reach NetCom <br/>"
//                              +"<br/> Please do not reply. <br/>"
//                              +"<br/><br/>"                              
//                            }                          
//                            transporter.sendMail( msg,function(err,info)
//                            {
//                              if(err)
//                              return false;
//                              else 
//                                return true;
//                              console.log(err)
//                            }); 
//                            rs(result1);                                                            
//                        }   
//                        catch (err) {
//                          await connection.rollback();
//                          rej(err);
//                        }
//                      })
//                      },




// Save_Job_Posting: async function (Job_Posting_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Job_Posting",
//                 [
//                     Job_Posting_.Job_Posting_Id,
//                     Job_Posting_.Job_Code,
//                     Job_Posting_.Job_Title,
//                     Job_Posting_.Descritpion,
//                     Job_Posting_.Skills,
//                     Job_Posting_.No_Of_Vaccancy,
//                     Job_Posting_.Experience,
//                     Job_Posting_.Experience_Name,
//                     Job_Posting_.Job_Location,
//                     Job_Posting_.Qualification,
//                     Job_Posting_.Qualification_Name,
//                     Job_Posting_.Functional_Area,
//                     Job_Posting_.Functional_Area_Name,
//                     Job_Posting_.Specialization,
//                     Job_Posting_.Specialization_Name,
//                     Job_Posting_.Salary,
//                     Job_Posting_.Last_Date,
//                     Job_Posting_.Company_Id,
//                     Job_Posting_.Company_Name,
//                     Job_Posting_.Address,
//                     Job_Posting_.Contact_Name,
//                     Job_Posting_.Contact_No,
//                     Job_Posting_.Email,
//                     Job_Posting_.Address1,
//                     Job_Posting_.Address2,
//                     Job_Posting_.Address3,

//                     Job_Posting_.Address4,
//                     Job_Posting_.Pincode,
//                     Job_Posting_.Status,
//                     Job_Posting_.tempFile_Nmae,
//                     Job_Posting_.User_Id,
//                     Job_Posting_.Course_Id,
//                     Job_Posting_.Course_Name,
//                     Job_Posting_.Gender_Id,
//                     Job_Posting_.Gender_Name,

//                 ],
//                 connection
//             ).result();

// // console.log(result1)
// var tempId=''
// var job_Id=''
// for(var i=0;i<result1.length;i++)
// {
//     if(result1[i].Device_Id !=null)
//     tempId =tempId + (result1[i].Device_Id) +',';
//     job_Id=result1[i].Job_Posting_Id
// }

// if(tempId.length>0)
//     tempId=tempId.substring(0,tempId.length-1)
// console.log(tempId)


// var message = {
// //     registration_ids:['deRyE2BAQlC_KDNxxTyG_Y:APA91bEzQuEaA3oFnKQqh_VRaY6IEAIjt5G1y2vV4-G75qFwmUQTzuJQaMzOzQ7GhTmNTAkaqTUBubEHyT-dRk9R8hMBeHVN76hG_1nHnM4izT7wST17i_XcPeYbKqCB_EPUaO2vOj4c',
// // 'fF-L8E2eTNa1ESdFlp_6IT:APA91bEYVdJecoxnRXPFbSd_4s3fGylQ0m5ZjR63XFLQkN2ZgUKdqD7PDE67lLDToSTjMFsO8hEgi9m0XclYVbjgSO4DwSCjvaQd4tYG6GiMWlZqhwSy3c7KX-GJqDoWY-NRNInYv15X'],
// registration_ids:[tempId ],
// notification: {
//         title: 'One Team',
//         body:  Job_Posting_.Job_Title ,
//     },
//     data: { title:job_Id,
//     Id:job_Id,
//     click_action: "profile",
    
//         //you can send only notification or only data(or include both)
//         // title: 'ok cdfsdsdfsd',
//         // body: '{"name": "12"}'
  
//     }
// };
// // data: { //you can send only notification or only data(or include both)
// //     title: 'ok cdfsdsdfsd',
// //     body: '{"name" : "okg ooggle ogrlrl","product_id" : "123","final_price" : "0.00035"}'
// // }
// fcm.send(message, function(err, response) {
//     if (err) {
//         console.log("Something has gone wrong!"+err);
//         console.log("Respponse:! "+response);
//     } else {
//         // showToast("Successfully sent with response");
//         console.log("Successfully sent with response: ", response);
//     }

// });




//             // for (var i = 0; i < result1.length; i++) {
//             //        "<tr><td>" + result1[i].Job_Posting_Id + "</td><td>" + result1[i].Student_Id + "</td><td>" + result1[i].Device_Id + "</td></tr>"
//             //     }

//             await connection.commit();
//             connection.release();
//             console.log(result1)
//             rs(result1);
//         } catch (err) {
//             await connection.rollback();
//             rej(err);
//             var result2 = [{ Student_Id_: 0 }];
            
//             rs(result2);
//         } finally {
//             connection.release();
//         }
//     });
// },




// Save_Job_Posting: async function (Job_Posting_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Job_Posting",
//                 [
//                     Job_Posting_.Job_Posting_Id,
//                     Job_Posting_.Job_Code,
//                     Job_Posting_.Job_Title,
//                     Job_Posting_.Descritpion,
//                     Job_Posting_.Skills,
//                     Job_Posting_.No_Of_Vaccancy,
//                     Job_Posting_.Experience,
//                     Job_Posting_.Experience_Name,
//                     Job_Posting_.Job_Location,
//                     Job_Posting_.Qualification,
//                     Job_Posting_.Qualification_Name,
//                     Job_Posting_.Functional_Area,
//                     Job_Posting_.Functional_Area_Name,
//                     Job_Posting_.Specialization,
//                     Job_Posting_.Specialization_Name,
//                     Job_Posting_.Salary,
//                     Job_Posting_.Last_Date,
//                     Job_Posting_.Company_Id,
//                     Job_Posting_.Company_Name,
//                     Job_Posting_.Address,
//                     Job_Posting_.Contact_Name,
//                     Job_Posting_.Contact_No,
//                     Job_Posting_.Email,
//                     Job_Posting_.Address1,
//                     Job_Posting_.Address2,
//                     Job_Posting_.Address3,

//                     Job_Posting_.Address4,
//                     Job_Posting_.Pincode,
//                     Job_Posting_.Status,
//                     Job_Posting_.tempFile_Nmae,
//                     Job_Posting_.User_Id,
//                     Job_Posting_.Course_Id,
//                     Job_Posting_.Course_Name,
//                     Job_Posting_.Gender_Id,
//                     Job_Posting_.Gender_Name,

//                 ],
//                 connection
//             ).result();

// // console.log(result1)
// var tempId=''
// var job_Id=''
// for(var i=0;i<result1.length;i++)
// {
//     if(result1[i].Device_Id !=null)
//     tempId =tempId + (result1[i].Device_Id) +',';
//     job_Id=result1[i].Job_Posting_Id
// }

// if(tempId.length>0)
//     tempId=tempId.substring(0,tempId.length-1)
// console.log(tempId)


// var message = {
// //     registration_ids:['deRyE2BAQlC_KDNxxTyG_Y:APA91bEzQuEaA3oFnKQqh_VRaY6IEAIjt5G1y2vV4-G75qFwmUQTzuJQaMzOzQ7GhTmNTAkaqTUBubEHyT-dRk9R8hMBeHVN76hG_1nHnM4izT7wST17i_XcPeYbKqCB_EPUaO2vOj4c',
// // 'fF-L8E2eTNa1ESdFlp_6IT:APA91bEYVdJecoxnRXPFbSd_4s3fGylQ0m5ZjR63XFLQkN2ZgUKdqD7PDE67lLDToSTjMFsO8hEgi9m0XclYVbjgSO4DwSCjvaQd4tYG6GiMWlZqhwSy3c7KX-GJqDoWY-NRNInYv15X'],
// registration_ids:[tempId ],
// notification: {
//         title: 'New Job',
//         body:  Job_Posting_.Job_Title ,
//     },
//     data: { title:job_Id,
//     Id:job_Id,
//     click_action: "profile",
    
//         //you can send only notification or only data(or include both)
//         // title: 'ok cdfsdsdfsd',
//         // body: '{"name": "12"}'
  
//     }
// };
// // data: { //you can send only notification or only data(or include both)
// //     title: 'ok cdfsdsdfsd',
// //     body: '{"name" : "okg ooggle ogrlrl","product_id" : "123","final_price" : "0.00035"}'
// // }
// fcm.send(message, function(err, response) {
//     if (err) {
//         console.log("Something has gone wrong!"+err);
//         console.log("Respponse:! "+response);
//     } else {
//         // showToast("Successfully sent with response");
//         console.log("Successfully sent with response: ", response);
//     }

// });




//             // for (var i = 0; i < result1.length; i++) {
//             //        "<tr><td>" + result1[i].Job_Posting_Id + "</td><td>" + result1[i].Student_Id + "</td><td>" + result1[i].Device_Id + "</td></tr>"
//             //     }

//             await connection.commit();
//             connection.release();
//             console.log(result1)
//             rs(result1);
//         } catch (err) {
//             await connection.rollback();
//             rej(err);
//             var result2 = [{ Student_Id_: 0 }];
            
//             rs(result2);
//         } finally {
//             connection.release();
//         }
//     });
// },




Save_Job_Posting: async function (Job_Posting_) {
    // console.log(Job_Posting_)
    return new Promise(async (rs, rej) => {
        const pool = db.promise();
        let result1;
        var connection = await pool.getConnection();
        try {
            const result1 = await new storedProcedure(
                "Save_Job_Posting",
                [
                    Job_Posting_.Job_Posting_Id,
                    Job_Posting_.Job_Code,
                    Job_Posting_.Job_Title,
                    Job_Posting_.Descritpion,
                    Job_Posting_.Skills,
                    Job_Posting_.No_Of_Vaccancy,
                    Job_Posting_.Experience,
                    Job_Posting_.Experience_Name,
                    Job_Posting_.Job_Location,
                    Job_Posting_.Qualification,
                    Job_Posting_.Qualification_Name,
                    Job_Posting_.Functional_Area,
                    Job_Posting_.Functional_Area_Name,
                    Job_Posting_.Specialization,
                    Job_Posting_.Specialization_Name,
                    Job_Posting_.Salary,
                    Job_Posting_.Last_Date,
                    Job_Posting_.Company_Id,
                    Job_Posting_.Company_Name,
                    Job_Posting_.Address,
                    Job_Posting_.Contact_Name,
                    Job_Posting_.Contact_No,
                    Job_Posting_.Email,
                    Job_Posting_.Address1,
                    Job_Posting_.Address2,
                    Job_Posting_.Address3,

                    Job_Posting_.Address4,
                    Job_Posting_.Pincode,
                    Job_Posting_.Status,
                    Job_Posting_.tempFile_Nmae,
                    Job_Posting_.User_Id,
                    Job_Posting_.Course_Id,
                    Job_Posting_.Course_Name,
                    Job_Posting_.Gender_Id,
                    Job_Posting_.Gender_Name,

                ],
                connection
            ).result();

 console.log(result1)
var tempId=''
var job_Id=''
for(var i=0;i<result1.length;i++)
{
    if(result1[i].Device_Id !=null)
//    tempId =tempId + (result1[i].Device_Id) +',';
tempId = (result1[i].Device_Id) ;
    job_Id=result1[i].Job_Posting_Id_
var message = {
registration_ids:[tempId ],
notification: {
        title: 'New Job',
        body:  Job_Posting_.Job_Title ,
    },
    data: { title:1,
    Id:job_Id,
    click_action: "1",
}
};
 
fcm.send(message, function(err, response) {
    if (err) {
        console.log("Something has gone wrong!"+err);
        console.log("Respponse:! "+response);
    } else {
        // showToast("Successfully sent with response");
        console.log("Successfully sent with response: ", response);
    }


});
}
            await connection.commit();
            connection.release();
            console.log(result1)
            rs(result1);
        } catch (err) {

            console.log(err)
            await connection.rollback();
            rej(err);
            var result2 = [{ Student_Id_: 0 }];
           console.log(result1, result2)
            rs(result2);
            // rs([result1, result2]);
        } finally {
            connection.release();
        }
    });
},

  



// Save_Schedule_Interview: async function (Interview_Schedule_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Schedule_Interview",
//                 [
//                     Interview_Schedule_.Interview_Schedule_Date,
//                     Interview_Schedule_.Applied_jobs,
//                     Interview_Schedule_.Interview_Schedule_Description,
//                     Interview_Schedule_.Login_User,
//                     Interview_Schedule_.Student_Id,
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)
// var tempId=''
// var job_Id=''
// for(var i=0;i<result1.length;i++)
// {
//     if(result1[i].Device_Id !=null)
//     tempId =tempId + (result1[i].Device_Id) +',';
//     job_Id=result1[i].Job_Id
// }

// if(tempId.length>0)
//     tempId=tempId.substring(0,tempId.length-1)
// console.log(tempId)


// var message = {
// //     registration_ids:['deRyE2BAQlC_KDNxxTyG_Y:APA91bEzQuEaA3oFnKQqh_VRaY6IEAIjt5G1y2vV4-G75qFwmUQTzuJQaMzOzQ7GhTmNTAkaqTUBubEHyT-dRk9R8hMBeHVN76hG_1nHnM4izT7wST17i_XcPeYbKqCB_EPUaO2vOj4c',
// // 'fF-L8E2eTNa1ESdFlp_6IT:APA91bEYVdJecoxnRXPFbSd_4s3fGylQ0m5ZjR63XFLQkN2ZgUKdqD7PDE67lLDToSTjMFsO8hEgi9m0XclYVbjgSO4DwSCjvaQd4tYG6GiMWlZqhwSy3c7KX-GJqDoWY-NRNInYv15X'],
// registration_ids:[tempId ],
// notification: {
//         title: 'New Job',
//         body:  result1.Job_Title ,
//     },
//     data: { title:job_Id,
//     Id:job_Id,
//     click_action: "profile",
    
//         //you can send only notification or only data(or include both)
//         // title: 'ok cdfsdsdfsd',
//         // body: '{"name": "12"}'
  
//     }
// };
// // data: { //you can send only notification or only data(or include both)
// //     title: 'ok cdfsdsdfsd',
// //     body: '{"name" : "okg ooggle ogrlrl","product_id" : "123","final_price" : "0.00035"}'
// // }
// fcm.send(message, function(err, response) {
//     if (err) {
//         console.log("Something has gone wrong!"+err);
//         console.log("Respponse:! "+response);
//     } else {
//         // showToast("Successfully sent with response");
//         console.log("Successfully sent with response: ", response);
//     }

// });




//             // for (var i = 0; i < result1.length; i++) {
//             //        "<tr><td>" + result1[i].Job_Posting_Id + "</td><td>" + result1[i].Student_Id + "</td><td>" + result1[i].Device_Id + "</td></tr>"
//             //     }

//             await connection.commit();
//             connection.release();
//             console.log(result1)
//             rs(result1);
//         } catch (err) {
//             await connection.rollback();
//             rej(err);
//             var result2 = [{ Student_Id_: 0 }];
            
//             rs(result2);
//         } finally {
//             connection.release();
//         }
//     });
// },













// Save_Mark_Placement: async function (Placement_Schedule_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Mark_Placement",
//                 [
//                     Placement_Schedule_.Placement_Schedule_Date,
//                     Placement_Schedule_.Applied_jobs,
//                     Placement_Schedule_.Placement_Schedule_Description,
//                     Placement_Schedule_.Login_User,
//                     Placement_Schedule_.Student_Id,
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)


// var tempId=''
// var job_Id=''
// for(var i=0;i<result1.length;i++)
// {
//     if(result1[i].Device_Id !=null)
//     tempId =tempId + (result1[i].Device_Id) +',';
//     job_Id=result1[i].Job_Id
// }


// // var jobtitle = result1.Job_Title 
// // console.log(jobtitle)

// if(tempId.length>0)
//     tempId=tempId.substring(0,tempId.length-1)
// console.log(tempId)


// var message = {
// //     registration_ids:['deRyE2BAQlC_KDNxxTyG_Y:APA91bEzQuEaA3oFnKQqh_VRaY6IEAIjt5G1y2vV4-G75qFwmUQTzuJQaMzOzQ7GhTmNTAkaqTUBubEHyT-dRk9R8hMBeHVN76hG_1nHnM4izT7wST17i_XcPeYbKqCB_EPUaO2vOj4c',
// // 'fF-L8E2eTNa1ESdFlp_6IT:APA91bEYVdJecoxnRXPFbSd_4s3fGylQ0m5ZjR63XFLQkN2ZgUKdqD7PDE67lLDToSTjMFsO8hEgi9m0XclYVbjgSO4DwSCjvaQd4tYG6GiMWlZqhwSy3c7KX-GJqDoWY-NRNInYv15X'],
// registration_ids:[tempId ],
// notification: {
//         title: 'New Job',
//         body:  result1.Job_Title ,
//     },
//     data: { title:job_Id,
//     Id:job_Id,
//     click_action: "profile",
    
//         //you can send only notification or only data(or include both)
//         // title: 'ok cdfsdsdfsd',
//         // body: '{"name": "12"}'
  
//     }
// };
// // data: { //you can send only notification or only data(or include both)
// //     title: 'ok cdfsdsdfsd',
// //     body: '{"name" : "okg ooggle ogrlrl","product_id" : "123","final_price" : "0.00035"}'
// // }
// fcm.send(message, function(err, response) {
//     if (err) {
//         console.log("Something has gone wrong!"+err);
//         console.log("Respponse:! "+response);
//     } else {
//         // showToast("Successfully sent with response");
//         console.log("Successfully sent with response: ", response);
//     }

// });




//             // for (var i = 0; i < result1.length; i++) {
//             //        "<tr><td>" + result1[i].Job_Posting_Id + "</td><td>" + result1[i].Student_Id + "</td><td>" + result1[i].Device_Id + "</td></tr>"
//             //     }

//             await connection.commit();
//             connection.release();
//             console.log(result1)
//             rs(result1);
//         } catch (err) {
//             await connection.rollback();
//             rej(err);
//             var result2 = [{ Student_Id_: 0 }];
            
//             rs(result2);
//         } finally {
//             connection.release();
//         }
//     });
// },





// Save_Schedule_Interview: async function (Interview_Schedule_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Schedule_Interview",
//                 [
//                     Interview_Schedule_.Interview_Schedule_Date,
//                     Interview_Schedule_.Applied_jobs,
//                     Interview_Schedule_.Interview_Schedule_Description,
//                     Interview_Schedule_.Login_User,
//                     Interview_Schedule_.Student_Id,
//                     Interview_Schedule_.Job_Id,
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)
//  var tempId=''
//  var job_Id=''
//  for(var i=0;i<result1.length;i++)
//  {
//      if(result1[i].Device_Id !=null)
//  //    tempId =tempId + (result1[i].Device_Id) +',';
//  tempId = (result1[i].Device_Id) ;
//      job_Id=result1[i].Job_Id
 
//  var message = {
    
//  registration_ids:[tempId ],
 
//  notification: {
    
//          title: 'Interview Scheduled',
//          body:	"at "+result1[i].Company_Name+ " on " +result1[i].Interview_Date+" . Description :"+result1[i].Interview_Description
                
//      },
//      data: { title:2,
//      Id:job_Id,
//      click_action: "1",
//  }
//  };
// //  console.log(message)
//  fcm.send(message, function(err, response) {
//      if (err) {
//          console.log("Something has gone wrong!"+err);
//          console.log("Respponse:! "+response);
//      } else {
//          // showToast("Successfully sent with response");
//          console.log("Successfully sent with response: ", response);
//      }
 
 
//  });
//  }
//              await connection.commit();
//              connection.release();
//              console.log(result1)
//              rs(result1);
//          } catch (err) {
//              await connection.rollback();
//              rej(err);
//              var result2 = [{ Student_Id_: 0 }];
            
//              rs(result2);
//          } finally {
//              connection.release();
//          }
//      });
//  },




 Save_Schedule_Interview: async function (Interview_Schedule_) {
    return new Promise(async (rs, rej) => {
        const pool = db.promise();
        let result1;
        var connection = await pool.getConnection();
        try {
           const result1 = await new storedProcedure(
                "Save_Schedule_Interview",
                [
                    Interview_Schedule_.Interview_Schedule_Date,
                    Interview_Schedule_.Applied_jobs,
                    Interview_Schedule_.Interview_Schedule_Description,
                    Interview_Schedule_.Login_User,
                    Interview_Schedule_.Student_Id,
                    Interview_Schedule_.Job_Id,
                   
                ],
                connection
            ).result();

 console.log(result1)


 var tempId=''
 var job_Id=''
 for(var i=0;i<result1.length;i++)
 {
     try {
    
     if(result1[i].Device_Id !=null && result1[i].Device_Id != '' )
{
 tempId = (result1[i].Device_Id) ;
     job_Id=result1[i].Job_Id
 var message = {
 registration_ids:[tempId ],
notification: {
    
         title: 'Interview Scheduled',
         body:	"at "+result1[i].Company_Name+ " on " +result1[i].Interview_Date+" . Description :"+result1[i].Interview_Description
                
     },
     data: { title:2,
     Id:job_Id,
     click_action: "1",
 }
 };
  
 fcm.send(message, function(err, response) {
     if (err) {
         console.log("Something has gone wrong!"+err);
         console.log("Respponse:! "+response);
     } else {
         // showToast("Successfully sent with response");
         console.log("Successfully sent with response: ", response);
     }
 
 
 });
}
} catch (err) {
    console.log(err)
    // await connection.rollback();
    // rej(err);
    // var result2 = [{ Student_Id_: 0 }];
   
    // rs(result2);
} finally {
    // connection.release();
}


 }
             await connection.commit();
             connection.release();
             console.log(result1)
             rs(result1);
         } catch (err) {
             await connection.rollback();
             rej(err);
             var result2 = [{ Student_Id_: 0 }];
            
             rs(result2);
         } finally {
             connection.release();
         }
     });
 },









// Save_Mark_Placement: async function (Placement_Schedule_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Save_Mark_Placement",
//                 [
//                     Placement_Schedule_.Placement_Schedule_Date,
//                     Placement_Schedule_.Applied_jobs,
//                     Placement_Schedule_.Placement_Schedule_Description,
//                     Placement_Schedule_.Login_User,
//                     Placement_Schedule_.Student_Id,
//                     Placement_Schedule_.Job_Id,
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)


//  var tempId=''
//  var job_Id=''
//  for(var i=0;i<result1.length;i++)
//  {
//      if(result1[i].Device_Id !=null)
//  //    tempId =tempId + (result1[i].Device_Id) +',';
//  tempId = (result1[i].Device_Id) ;
//      job_Id=result1[i].Job_Id
//  var message = {
//  registration_ids:[tempId ],
//  notification: {
//          title: 'Placed',
//          body:	"at "+result1[i].Company_Name+ " on " +result1[i].Placement_Date
//      },
//      data: { title:3,
//      Id:job_Id,
//      click_action: "1",
//  }
//  };
  
//  fcm.send(message, function(err, response) {
//      if (err) {
//          console.log("Something has gone wrong!"+err);
//          console.log("Respponse:! "+response);
//      } else {
//          // showToast("Successfully sent with response");
//          console.log("Successfully sent with response: ", response);
//      }
 
 
//  });
//  }
//              await connection.commit();
//              connection.release();
//              console.log(result1)
//              rs(result1);
//          } catch (err) {
//              await connection.rollback();
//              rej(err);
//              var result2 = [{ Student_Id_: 0 }];
            
//              rs(result2);
//          } finally {
//              connection.release();
//          }
//      });
//  },


Save_Mark_Placement: async function (Placement_Schedule_) {
    return new Promise(async (rs, rej) => {
        const pool = db.promise();
        let result1;
        var connection = await pool.getConnection();
        try {
            const result1 = await new storedProcedure(
                "Save_Mark_Placement",
                [
                    Placement_Schedule_.Placement_Schedule_Date,
                    Placement_Schedule_.Applied_jobs,
                    Placement_Schedule_.Placement_Schedule_Description,
                    Placement_Schedule_.Login_User,
                    Placement_Schedule_.Student_Id,
                    Placement_Schedule_.Job_Id,
                   
                ],
                connection
            ).result();

 console.log(result1)


 var tempId=''
 var job_Id=''
 for(var i=0;i<result1.length;i++)
 {
     try {
    
     if(result1[i].Device_Id !=null && result1[i].Device_Id != '' )
{
 tempId = (result1[i].Device_Id) ;
     job_Id=result1[i].Job_Id
 var message = {
 registration_ids:[tempId ],
 notification: {
         title: 'Placed',
         body:	"at "+result1[i].Company_Name+ " on " +result1[i].Placement_Date
     },
     data: { title:3,
     Id:job_Id,
     click_action: "1",
 }
 };
  
 fcm.send(message, function(err, response) {
     if (err) {
         console.log("Something has gone wrong!"+err);
         console.log("Respponse:! "+response);
     } else {
         // showToast("Successfully sent with response");
         console.log("Successfully sent with response: ", response);
     }
 
 
 });
}
} catch (err) {
    console.log(err)
    // await connection.rollback();
    // rej(err);
    // var result2 = [{ Student_Id_: 0 }];
   
    // rs(result2);
} finally {
    // connection.release();
}


 }
             await connection.commit();
             connection.release();
             console.log(result1)
             rs(result1);
         } catch (err) {
             await connection.rollback();
             rej(err);
             var result2 = [{ Student_Id_: 0 }];
            
             rs(result2);
         } finally {
             connection.release();
         }
     });
 },








//  Update_Resume_Status: async function (Resume_Status_Change_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Update_Resume_Status",
//                 [
//                     Resume_Status_Change_.Resume_Status_Id,
//                     Resume_Status_Change_.Resume_Status_Name,
//                     Resume_Status_Change_.Student_Id,
                  
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)


//  var tempId=''
//  var job_Id=''
//  for(var i=0;i<result1.length;i++)
//  {
//      if(result1[i].Change_status_ ==1)

//  tempId = (result1[i].Device_Id) ;
//     //  job_Id=result1[i].Job_Id
//  var message = {
//  registration_ids:[tempId ],
//  notification: {
//          title: 'Resume Status Changed',
//          body: "Your Resume " +result1[i].Resume_Status_Name_  ,
//      },
//      data: { title:4,
//      Id:job_Id,
//      click_action: "1",
//  }
//  };
  
//  fcm.send(message, function(err, response) {
//      if (err) {
//          console.log("Something has gone wrong!"+err);
//          console.log("Respponse:! "+response);
//      } else {
//          // showToast("Successfully sent with response");
//          console.log("Successfully sent with response: ", response);
//      }
 
 
//  });
//  }
//              await connection.commit();
//              connection.release();
//              console.log(result1)
//              rs(result1);
//          } catch (err) {
//              await connection.rollback();
//              rej(err);
//              var result2 = [{ Student_Id_: 0 }];
            
//              rs(result2);
//          } finally {
//              connection.release();
//          }
//      });
//  },





        

 Update_Resume_Status: async function (Resume_Status_Change_) {
    return new Promise(async (rs, rej) => {
        const pool = db.promise();
        let result1;
        var connection = await pool.getConnection();
        try {
            const result1 = await new storedProcedure(
                "Update_Resume_Status",
                [
                    Resume_Status_Change_.Resume_Status_Id,
                    Resume_Status_Change_.Resume_Status_Name,
                    Resume_Status_Change_.Student_Id,
                  
                   
                ],
                connection
            ).result();

 console.log(result1)


 var tempId=''
 var job_Id=''
 for(var i=0;i<result1.length;i++)
 {
     try {
    
     if(result1[i].Device_Id !=null && result1[i].Device_Id != ''&&result1[i].Change_status_ ==1 )
{
 tempId = (result1[i].Device_Id) ;
    //  job_Id=result1[i].Job_Id
 var message = {
 registration_ids:[tempId ],
 notification: {
    title: 'Resume Status Changed',
    body: "Your Resume " +result1[i].Resume_Status_Name_  ,
     },
     data: { title:4,
     Id:job_Id,
     click_action: "1",
 }
 };
  
 fcm.send(message, function(err, response) {
     if (err) {
         console.log("Something has gone wrong!"+err);
         console.log("Respponse:! "+response);
     } else {
         // showToast("Successfully sent with response");
         console.log("Successfully sent with response: ", response);
     }
 
 
 });
}
} catch (err) {
    console.log(err)
    // await connection.rollback();
    // rej(err);
    // var result2 = [{ Student_Id_: 0 }];
   
    // rs(result2);
} finally {
    // connection.release();
}


 }
             await connection.commit();
             connection.release();
             console.log(result1)
             rs(result1);
         } catch (err) {
             await connection.rollback();
             rej(err);
             var result2 = [{ Student_Id_: 0 }];
            
             rs(result2);
         } finally {
             connection.release();
         }
     });
 },

















//   Update_Resume_Status: async function (Resume_Status_Change_) {
//     return new Promise(async (rs, rej) => {
//         const pool = db.promise();
//         let result1;
//         var connection = await pool.getConnection();
//         try {
//             const result1 = await new storedProcedure(
//                 "Update_Resume_Status",
//                 [
//                     Resume_Status_Change_.Resume_Status_Id,
//                     Resume_Status_Change_.Resume_Status_Name,
//                     Resume_Status_Change_.Student_Id,
                  
                   
//                 ],
//                 connection
//             ).result();

//  console.log(result1)


//  var tempId=''
//  var Resume_Status_Id=''
// //  for(var i=0;i<result1.length;i++)
// if(result1.Change_status_ ==1)
//  {
//  tempId = (result1.Device_Id) ;
//       Resume_Status_Id= Resume_Status_Change_.Resume_Status_Id
//  var message = {
//  registration_ids:[tempId ],
//  notification: {
//          title: 'Resume Status Change',
//          body:  result1.Resume_Status_Name_  ,
//      },
//      data: { title:1,
//      Id:Resume_Status_Id,
//      click_action: "1",
//  }
//  };
  
//  fcm.send(message, function(err, response) {
//      if (err) {
//          console.log("Something has gone wrong!"+err);
//          console.log("Respponse:! "+response);
//      } else {
//          // showToast("Successfully sent with response");
//          console.log("Successfully sent with response: ", response);
//      }
 
 
//  });
//  }
//              await connection.commit();
//              connection.release();
//              console.log(result1)
//              rs(result1);
//          } catch (err) {
//              await connection.rollback();
//              rej(err);
//              var result2 = [{ Student_Id_: 0 }];
            
//              rs(result2);
//          } finally {
//              connection.release();
//          }
//      });
//  },

           

};
module.exports=Job_Posting;

